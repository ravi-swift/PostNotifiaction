//
//  ThirdViewController.swift
//  PostNotification
//
//  Created by Rp on 14/12/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func clickhere(){
        
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadtitle"), object: nil, userInfo: nil)  // use for post notification 1. Register notification
        
        self.navigationController?.popToRootViewController(animated: true)
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
