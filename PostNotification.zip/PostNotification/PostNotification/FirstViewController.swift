//
//  FirstViewController.swift
//  PostNotification
//
//  Created by Rp on 14/12/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {
    
    @IBOutlet var lbl : UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let leftbarbtn = UIBarButtonItem.init(title: "Next>", style: .plain, target: self, action: #selector(ClickOnNext))
        self.navigationItem.rightBarButtonItem = leftbarbtn
        
        NotificationCenter.default.addObserver(self, selector: #selector(settitle), name: NSNotification.Name(rawValue: "reloadtitle"), object: nil) // use for post notification 2. call methode
    }
    
    @objc func settitle()
    {
        lbl.text = "HDFC: Mortgage lender HDFC will raise up to Rs 1,500 crore by issuing bonds on a private placement basis. The 'HDFC Series U-006 June 18, 2020' secured redeemable non-convertible debentures will open for subscription on December 17 and close the same day, HDFC said in a regulatory filing Thursday."
        lbl.numberOfLines = 0
        lbl.sizeToFit()
    }
    
    @objc func ClickOnNext(){
        
        let SecoundVc = self.storyboard?.instantiateViewController(withIdentifier: "SecoundViewController") as! SecoundViewController
        self.navigationController?.pushViewController(SecoundVc, animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
